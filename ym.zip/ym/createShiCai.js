var template=`
<div>
    <div style="margin-bottom:16px;">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/shicai' }">食材管理</el-breadcrumb-item>
        <el-breadcrumb-item>生成食材</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-table :data="shengchengshicaitabledata"
        style="width: 100%"  :default-sort = "{prop: 'xuqiuNum', order: 'descending'}"
        tooltip-effect="dark">
        <el-table-column type="expand">
  <template slot-scope="props">
    <el-form label-position="left" inline class="demo-table-expand">
      <el-form-item label="商品名称">
        <span>{{ props.row.name }}</span>
      </el-form-item>
      <el-form-item label="所属店铺">
        <span>{{ props.row.shop }}</span>
      </el-form-item>
      <el-form-item label="商品 ID">
        <span>{{ props.row.id }}</span>
      </el-form-item>
      <el-form-item label="店铺 ID">
        <span>{{ props.row.shopId }}</span>
      </el-form-item>
      <el-form-item label="商品分类">
        <span>{{ props.row.category }}</span>
      </el-form-item>
      <el-form-item label="店铺地址">
        <span>{{ props.row.address }}</span>
      </el-form-item>
      <el-form-item label="商品描述">
        <span>{{ props.row.desc }}</span>
      </el-form-item>
    </el-form>
  </template>
</el-table-column>
        <el-table-column type="selection"   width="55"></el-table-column>
        <el-table-column  prop="name"  label="食材名称" sortable ></el-table-column>
        <el-table-column  prop="xuqiuNum"  label="实际需求量"  sortable ></el-table-column>
        <el-table-column  prop="kucun" label="库存"></el-table-column>
        <el-table-column  prop="zhanyong"  label="被占用" sortable></el-table-column>
        <el-table-column  prop="gujia"  label="今日估价"  sortable></el-table-column>
        <el-table-column  prop="baifenbi" label="变化百分比（与前次估价对比）"></el-table-column>
        <el-table-column  prop="huizong"  label="汇总" sortable></el-table-column>
        <el-table-column  prop="caigouNum"  label="实际采购量"  sortable></el-table-column>
    </el-table>

</div>
`;

var createShiCai = Vue.component('createShiCai',
  {
    template:template,
    data() {
      return {
          shengchengshicaitabledata:[
            {
              name:'1',
              xuqiuNum:'1',
              kucun:'1',
              zhanyong:'1',
              gujia:'1',
              baifenbi:'1',
              huizong:'1',
              caigouNum:'1'
            }
          ]
      }
  },
  methods(){

  }
})
