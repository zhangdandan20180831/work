var template = `
<div>
<el-form :inline="true" :label-position="labelPosition" label-width="80px" :model="formInline"  class="demo-form-inline">
  <el-form-item label="模版名称">
    <el-input v-model="formInline.templateName" placeholder="模版名称"></el-input>
  </el-form-item>
  <el-form-item label="时间段">
      <el-select v-model="formInline.emlns" placeholder="时间段">
        <el-option label="早" value="早"></el-option>
        <el-option label="中" value="中"></el-option>
        <el-option label="晚" value="晚"></el-option>
        <el-option label="夜" value="夜"></el-option>
      </el-select>
  </el-form-item>
  <el-form-item label="食堂名称">
    <el-input v-model="formInline.diningRoomName" placeholder="食堂名称"></el-input>
  </el-form-item>
  <el-form-item label="窗口名称">
    <el-input v-model="formInline.windowName" placeholder="窗口名称"></el-input>
  </el-form-item>
  <el-form-item label="适用日期">
    <el-date-picker
      v-model="formInline.templateDate"
      type="month"
      placeholder="选择月">
    </el-date-picker>
  </el-form-item>
  <el-form-item>
    <el-button type="danger" icon="el-icon-search" size="medium" @click="onSubmit">查询</el-button>
  </el-form-item>
</el-form>
<el-button type="primary" icon="el-icon-plus" @click="dialogVisible = true" size="small">新建模板</el-button>
<mobanTable>

</mobanTable>
<el-dialog title="新建模板"  :visible.sync="dialogVisible"  width="50%">
    <el-row>
      <el-form :inline="true" ref="xinjianmobanmodel" :model="xinjianmobanmodel" label-width="80px" :label-position="labelPosition" label-width="80px" class="demo-form-inline">
        <el-col :span="12">
            <div class="grid-content bg-purple">
                  <el-form-item label="模板名称">
                    <el-input v-model="xinjianmobanmodel.name" style="width:300px;"></el-input>
                  </el-form-item>
            </div>
        </el-col>
        <el-col :span="12">
            <div class="grid-content bg-purple-light">
                <el-form-item label="适用日期">
                    <el-date-picker  v-model="xinjianmobanmodel.data"  type="daterange"  range-separator="至"  start-placeholder="开始日期"  end-placeholder="结束日期" format="yyyy - MM - dd"
                        value-format="yyyy-MM-dd">
                    </el-date-picker>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="12">
            <div class="grid-content bg-purple">
                  <el-form-item label="学校">
                    <el-input v-model="xinjianmobanmodel.school" style="width:300px;"></el-input>
                  </el-form-item>
            </div>
        </el-col>
        <el-col :span="12">
            <div class="grid-content bg-purple-light">
                <el-form-item label="校区">
                    <el-select v-model="xinjianmobanmodel.xiaoqu" placeholder="请选择" clearable style="width:300px;">
                        <el-option v-for="item in options"  :key="item.value"  :label="item.label"  :value="item.value">  </el-option>
                    </el-select>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="12">
            <div class="grid-content bg-purple-light">
                <el-form-item label="食堂">
                    <el-select v-model="xinjianmobanmodel.shitang" placeholder="请选择" clearable style="width:300px;">
                        <el-option  v-for="item in options"  :key="item.value"  :label="item.label"  :value="item.value">  </el-option>
                    </el-select>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="12">
            <div class="grid-content bg-purple-light">
                <el-form-item label="窗口">
                    <el-select v-model="xinjianmobanmodel.chuangkou" placeholder="请选择" clearable style="width:300px;">
                        <el-option  v-for="item in options"  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="24">
            <div class="grid-content bg-purple-light">
                <el-form-item label="时间段">
                    <el-checkbox-group v-model="xinjianmobanmodel.checkList">
                      <el-checkbox label="早">早</el-checkbox>
                      <el-checkbox label="中">中</el-checkbox>
                      <el-checkbox label="晚">晚</el-checkbox>
                      <el-checkbox label="夜">夜</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="18">
            <div class="grid-content bg-purple-light">
                <el-form-item label="周期">
                    <el-checkbox-group v-model="xinjianmobanmodel.zhouqi">
                        <el-checkbox label="周一">周一</el-checkbox>
                        <el-checkbox label="周二">周二</el-checkbox>
                        <el-checkbox label="周三">周三</el-checkbox>
                        <el-checkbox label="周四">周四</el-checkbox>
                        <el-checkbox label="周五">周五</el-checkbox>
                        <el-checkbox label="周六">周六</el-checkbox>
                        <el-checkbox label="周日">周日</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
            </div>
        </el-col>
        <el-col :span="6">
            <div class="grid-content bg-purple-light">
                <el-form-item label="">
                    <el-button type="primary">另存为</el-button>
                    <el-button type="primary" @click="addcaipin = true">添加菜品</el-button>
                </el-form-item>
            </div>
        </el-col>
      </el-form>
    </el-row>
    <el-table  :data="xinjianmobanmodel.mobanmodeltable"  style="width: 100%" border>
      <el-table-column  prop="caiming"  label="菜名">  </el-table-column>
      <el-table-column  prop="zhizhuo"  label="单位制作量"></el-table-column>
      <el-table-column  prop="yugu"  label="预估份数"></el-table-column>
      <el-table-column  label="操作">
            <template slot-scope="scope">
              <el-button type="danger" icon="el-icon-delete" size="small" @click.native.prevent="deleteRow(scope.$index, xinjianmobanmodel.mobanmodeltable)"></el-button>
            </template>
      </el-table-column>
  </el-table>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
<el-dialog  title="添加菜品" :visible.sync="addcaipin"  width="55%">
    <el-form :inline="true" :model="addcaipinfrom" class="demo-form-inline">
        <el-form-item label="选择菜系">
          <el-select v-model="addcaipinfrom.selectCaixi" placeholder="选择菜系">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="选择细类">
          <el-select v-model="addcaipinfrom.xilei" placeholder="选择细类">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="选择菜名">
          <el-input v-model="addcaipinfrom.caiming" placeholder="选择菜名"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">查询</el-button>
        </el-form-item>
    </el-form>
    {{addcaipinids}}
    <el-table  ref="addcaipinData"  :data="addcaipinData"  tooltip-effect="dark"  style="width: 100%"  @selection-change="xinJianCaiPinGetId" border>
        <el-table-column  type="selection"  width="55" text-align="center"></el-table-column>
        <el-table-column  prop="caiming"  label="菜名" text-align="center">  </el-table-column>
        <el-table-column  prop="zuishaozhizuoliang"  label="最少制作量"  text-align="center">  </el-table-column>
    </el-table>

  <span slot="footer" class="dialog-footer">
    <el-button @click="addcaipin = false">取 消</el-button>
    <el-button type="primary" @click="submitDo">确 定</el-button>
  </span>
</el-dialog>


</div>

`;
var manageTemplates = Vue.component('manageTemplates',
  {
    template:template,
    watch: {
			data () {
				alert(7)
			}
		},
    data() {
      return {
        labelPosition :'right',
        formInline: {
            templateName: '',
            emlns : '',
            diningRoomName : '',
            windowName : '',
            templateDate : '',
        },
        xinjianmobanmodel: {
          // 新建模板数据
          name:'',
          data: '',
          school:'',
          xiaoqu:'',
          shitang:'',
          chuangkou:'',
          checkList: ['早','中'],
          zhouqi:['周一','周二'],
          mobanmodeltable:[{
            caiming:'鱼香肉丝',
            zhizhuo:'1000',
            yugu:'500'

          }]
        },
        dialogVisible: false,
        addcaipin : false,
        options: [{
          value: '选项1',
          label: '北京理工大学'
        }],
        value: '',
        addcaipinfrom:{
          //添加菜品model数据查询条件
          selectCaixi:'',
          xilei:'',
          caiming:''
        },
        addcaipinData:[
          //添加菜品表格内的数据
          {
            id:'1',
            caiming:'鱼香肉丝',
            zuishaozhizuoliang:'1000'
          },
          {
            id:'2',
            caiming:'鱼香肉丝2',
            zuishaozhizuoliang:'1000'
          }
        ],
        addcaipinids:[]//添加菜品选中的所有id

      }
  },
  methods: {
       onSubmit() {
         console.log('submit!');
       },
      deleteRow(index, rows) {
        rows.splice(index, 1);
      },
      xinJianCaiPinGetId(id) {
        //添加菜品model取出id
          this.addcaipinids = id;
      },
      submitDo(){
           this.xinjianmobanmodel.mobanmodeltable = this.addcaipinids;
           this.addcaipinData = false;
       }
   }
}
)
