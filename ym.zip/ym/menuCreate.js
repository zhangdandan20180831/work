var template = `<div>
<el-table
    :data="tableData5"
    style="width: 100%"
    height="700"
    :border="border">
    <el-table-column type="expand">
    <template slot-scope="props">
        <!-- 展开选择菜单 -->
        <el-button type="primary" icon="el-icon-edit" size="small">选择模板</el-button>
        <el-button type="primary" icon="el-icon-search" size="small" @click="openChooseDishes(props.$index)">选择菜品</el-button>
        <el-table
            stripe
            :data="props.row.dishes"
            style="width: 100%">
            <el-table-column
              prop="name"
              label="菜品名称"
              >
            </el-table-column>
            <el-table-column
              prop="unitnum"
              label="单位制作量"
              >
            </el-table-column>
            <el-table-column
              prop="expect"
              label="预估份数">
            </el-table-column>
            <el-table-column
              label="操作">
              <template slot-scope="scope">
                 <el-button type="danger" size="small" icon="el-icon-delete" @click="deleteDishesByIndex(props.$index,scope.$index)"></el-button>
              </template>
            </el-table-column>
          </el-table>
    </template>
    </el-table-column>
    <el-table-column
      label="食堂"
      prop="id">
    </el-table-column>
    <el-table-column
      label="档口"
      prop="name">
    </el-table-column>
    <el-table-column
      label="日期"
      prop="desc">
    </el-table-column>
    <el-table-column
      label="时间段"
      prop="time">
    </el-table-column>
  </el-table>

  <el-row style="margin-bottom:10px">
     <el-col :span="24" align="right">
     <el-button type="primary" icon="el-icon-edit" >提交</el-button>
     <el-button type="primary" icon="el-icon-edit" >上一步</el-button>
     </el-col>
  </el-row>

  <dishAdd @choose="chooseDishes" @close="closeDishes" :dialogDishes="dialogDishes"></dishAdd>
</div>
`;
var menuCreate = Vue.component('menuCreate',
  {
    template:template,
    data() {
      return {
        border:true,
        dialogDishes:false,
        tableData5: [{
          id: '第一食堂',
          name: '第一档口',
          desc: '2017-12-01',
          time: '早',
          dishes:[{
            name: '西红柿炒鸡蛋',
            unitnum: '150',
            expect: '200'
          },{
            name: '酸辣土豆丝',
            unitnum: '100',
            expect: '200'
          },{
            name: '尖椒豆皮',
            unitnum: '300',
            expect: '200'
          }]
        },{
          id: '第一食堂',
          name: '第2档口',
          category: '江浙小吃、小吃零食',
          desc: '2017-12-01',
          time: '早',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10333',
          dishes:[]
        }, {
          id: '第二食堂',
          name: '川菜档口',
          category: '江浙小吃、小吃零食',
          desc: '2017-12-01',
          time: '早',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10333',
          dishes:[]
        }, {
          id: '12987125',
          name: '好滋好味鸡蛋仔',
          category: '江浙小吃、小吃零食',
          desc: '荷兰优质淡奶，奶香浓而不腻',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10333',
          dishes:[]
        }, {
          id: '12987126',
          name: '好滋好味鸡蛋仔',
          category: '江浙小吃、小吃零食',
          desc: '荷兰优质淡奶，奶香浓而不腻',
          address: '上海市普陀区真北路',
          shop: '王小虎夫妻店',
          shopId: '10333',
          dishes:[]
        }],
        // 查询出来的菜品列表
        tableData2: [{
          name: '西红柿炒鸡蛋',
          unitnum: '150',
          expect: '200'
        },{
          name: '酸辣土豆丝',
          unitnum: '100',
          expect: '200'
        },{
          name: '尖椒豆皮',
          unitnum: '300',
          expect: '200'
        }],
        //打开对话框的行
        chooseIndex:''
      }
    },
    methods: {
      openChooseDishes(index){
        //记录数据
        this.chooseIndex=index;
        //显示弹窗
        this.dialogDishes=true;
      },
      chooseDishes(multipleSelection){
        for (var i in multipleSelection) {
          // 判断重复添加添加
          this.tableData5[this.chooseIndex].dishes.push(multipleSelection[i])
        }
        //显示弹窗
        this.dialogDishes=false;
      },
      closeDishes(val){
        this.dialogDishes=val;
      },
      // 删除菜品
      deleteDishesByIndex(rowIndex,dishesIndex){
        this.tableData5[rowIndex].dishes.splice(dishesIndex, 1)
      }
    }
  }
)
