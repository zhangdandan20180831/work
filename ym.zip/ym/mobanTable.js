var template = `
<div>
<el-dialog  title="详情"  :visible.sync="mobanxiangqingModel"  width="30%"  :before-close="handleClose">
  <span>这是一段信息</span>
  <span slot="footer" class="dialog-footer">
    <el-button @click="mobanxiangqingModel = false">取 消</el-button>
    <el-button type="primary" @click="mobanxiangqingModel = false">确 定</el-button>
  </span>
</el-dialog>
  <el-table :data="mobanTableDatas"  style="width: 100%">
    <el-table-column fixed prop="name" label="模版名称" width="200"></el-table-column>
    <el-table-column fixed prop="date" label="有效期" width="100"></el-table-column>
    <el-table-column fixed prop="school" label="学校" width="200"></el-table-column>
    <el-table-column fixed prop="xiaoqu" label="校区" width="150"></el-table-column>
    <el-table-column fixed prop="shitangname" label="食堂名称" width="200"></el-table-column>
    <el-table-column fixed prop="dangkou" label="档口" width="160"></el-table-column>
    <el-table-column fixed label="操作" width="90">
      <template slot-scope="scope">
        <el-button @click="mobanxiangqingModel = true" type="text" size="small">详情</el-button>
        <el-button @click.native.prevent="deleteRow(scope.$index, mobanTableDatas)" type="text" size="small">删除</el-button>
      </template>
    </el-table-column>
    <el-table-column label="天数">
          <el-table-column label="一">
              <el-table-column label="早" prop="zao" width="40" >
                    <template slot-scope="scope" v-if="scope.row.zao === '1'">
                        <el-button type="text"><i class="el-icon-check"></i>{{scope.row.zao}}</el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-if="scope.row.zhong === '1'">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope" v-if="scope.row.wan === '1'">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope" v-if="scope.row.ye === '1'">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
          </el-table-column>
          <el-table-column label="二">
              <el-table-column label="早" prop="zao" width="40" >
                    <template slot-scope="scope" v-if="scope.row.zao === '1'">
                        <el-button type="text"><i class="el-icon-check"></i>{{scope.row.zao}}</el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-show="zhong">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="三">
                <el-table-column label="早" prop="zao" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="中" prop="zhong" width="40">
                      <template slot-scope="scope" v-show="zhong">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="晚" prop="wan" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="夜" prop="ye" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="四">
                  <el-table-column label="早" prop="zao" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="中" prop="zhong" width="40">
                        <template slot-scope="scope" v-show="zhong">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="晚" prop="wan" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                  <el-table-column label="夜" prop="ye" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                </el-table-column>
                <el-table-column label="五">
                    <el-table-column label="早" prop="zao" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="中" prop="zhong" width="40">
                          <template slot-scope="scope" v-show="zhong">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="晚" prop="wan" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="夜" prop="ye" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                  </el-table-column>
  <el-table-column label="六">
      <el-table-column label="早" prop="zao" width="40">
            <template slot-scope="scope">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
      </el-table-column>
      <el-table-column label="中" prop="zhong" width="40">
            <template slot-scope="scope" v-show="zhong">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
      </el-table-column>
      <el-table-column label="晚" prop="wan" width="40">
          <template slot-scope="scope">
              <el-button type="text"><i class="el-icon-check"></i></el-button>
          </template>
      </el-table-column>
      <el-table-column label="夜" prop="ye" width="40">
          <template slot-scope="scope">
              <el-button type="text"><i class="el-icon-check"></i></el-button>
          </template>
      </el-table-column>
    </el-table-column>
    <el-table-column label="七">
        <el-table-column label="早" prop="zao" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
        </el-table-column>
        <el-table-column label="中" prop="zhong" width="40">
              <template slot-scope="scope" v-show="zhong">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
        </el-table-column>
        <el-table-column label="晚" prop="wan" width="40">
            <template slot-scope="scope">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
        </el-table-column>
        <el-table-column label="夜" prop="ye" width="40">
            <template slot-scope="scope">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="八">
          <el-table-column label="早" prop="zao" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="中" prop="zhong" width="40">
                <template slot-scope="scope" v-show="zhong">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="晚" prop="wan" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
          <el-table-column label="夜" prop="ye" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="九">
            <el-table-column label="早" prop="zao" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="中" prop="zhong" width="40">
                  <template slot-scope="scope" v-show="zhong">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="晚" prop="wan" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
            <el-table-column label="夜" prop="ye" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
          </el-table-column>
         <el-table-column label="十">
            <el-table-column label="早" prop="zao" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="中" prop="zhong" width="40">
                  <template slot-scope="scope" v-show="zhong">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="晚" prop="wan" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
            <el-table-column label="夜" prop="ye" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
          </el-table-column>

          <el-table-column label="十一">
              <el-table-column label="早" prop="zao" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-show="zhong">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="十二">
                <el-table-column label="早" prop="zao" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="中" prop="zhong" width="40">
                      <template slot-scope="scope" v-show="zhong">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="晚" prop="wan" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="夜" prop="ye" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="十三">
                  <el-table-column label="早" prop="zao" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="中" prop="zhong" width="40">
                        <template slot-scope="scope" v-show="zhong">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="晚" prop="wan" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                  <el-table-column label="夜" prop="ye" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                </el-table-column>
                <el-table-column label="十四">
                    <el-table-column label="早" prop="zao" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="中" prop="zhong" width="40">
                          <template slot-scope="scope" v-show="zhong">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="晚" prop="wan" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="夜" prop="ye" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                  </el-table-column>
                  <el-table-column label="十五">
                      <el-table-column label="早" prop="zao" width="40">
                            <template slot-scope="scope">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                      </el-table-column>
                      <el-table-column label="中" prop="zhong" width="40">
                            <template slot-scope="scope" v-show="zhong">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                      </el-table-column>
                      <el-table-column label="晚" prop="wan" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                      </el-table-column>
                      <el-table-column label="夜" prop="ye" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                      </el-table-column>
                    </el-table-column>
    <el-table-column label="十六">
        <el-table-column label="早" prop="zao" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
        </el-table-column>
        <el-table-column label="中" prop="zhong" width="40">
              <template slot-scope="scope" v-show="zhong">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
        </el-table-column>
        <el-table-column label="晚" prop="wan" width="40">
            <template slot-scope="scope">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
        </el-table-column>
        <el-table-column label="夜" prop="ye" width="40">
            <template slot-scope="scope">
                <el-button type="text"><i class="el-icon-check"></i></el-button>
            </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="十七">
          <el-table-column label="早" prop="zao" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="中" prop="zhong" width="40">
                <template slot-scope="scope" v-show="zhong">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="晚" prop="wan" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
          <el-table-column label="夜" prop="ye" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="十八">
            <el-table-column label="早" prop="zao" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="中" prop="zhong" width="40">
                  <template slot-scope="scope" v-show="zhong">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="晚" prop="wan" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
            <el-table-column label="夜" prop="ye" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
          </el-table-column>
          <el-table-column label="十九">
              <el-table-column label="早" prop="zao" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-show="zhong">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
            </el-table-column>
           <el-table-column label="二十">
              <el-table-column label="早" prop="zao" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-show="zhong">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
            </el-table-column>


            <el-table-column label="二一">
                <el-table-column label="早" prop="zao" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="中" prop="zhong" width="40">
                      <template slot-scope="scope" v-show="zhong">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="晚" prop="wan" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="夜" prop="ye" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="二二">
                  <el-table-column label="早" prop="zao" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="中" prop="zhong" width="40">
                        <template slot-scope="scope" v-show="zhong">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                  </el-table-column>
                  <el-table-column label="晚" prop="wan" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                  <el-table-column label="夜" prop="ye" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                  </el-table-column>
                </el-table-column>
                <el-table-column label="二三">
                    <el-table-column label="早" prop="zao" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="中" prop="zhong" width="40">
                          <template slot-scope="scope" v-show="zhong">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                    </el-table-column>
                    <el-table-column label="晚" prop="wan" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="夜" prop="ye" width="40">
                        <template slot-scope="scope">
                            <el-button type="text"><i class="el-icon-check"></i></el-button>
                        </template>
                    </el-table-column>
                  </el-table-column>
                  <el-table-column label="二四">
                      <el-table-column label="早" prop="zao" width="40">
                            <template slot-scope="scope">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                      </el-table-column>
                      <el-table-column label="中" prop="zhong" width="40">
                            <template slot-scope="scope" v-show="zhong">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                      </el-table-column>
                      <el-table-column label="晚" prop="wan" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                      </el-table-column>
                      <el-table-column label="夜" prop="ye" width="40">
                          <template slot-scope="scope">
                              <el-button type="text"><i class="el-icon-check"></i></el-button>
                          </template>
                      </el-table-column>
                    </el-table-column>
                    <el-table-column label="二五">
                        <el-table-column label="早" prop="zao" width="40">
                              <template slot-scope="scope">
                                  <el-button type="text"><i class="el-icon-check"></i></el-button>
                              </template>
                        </el-table-column>
                        <el-table-column label="中" prop="zhong" width="40">
                              <template slot-scope="scope" v-show="zhong">
                                  <el-button type="text"><i class="el-icon-check"></i></el-button>
                              </template>
                        </el-table-column>
                        <el-table-column label="晚" prop="wan" width="40">
                            <template slot-scope="scope">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                        </el-table-column>
                        <el-table-column label="夜" prop="ye" width="40">
                            <template slot-scope="scope">
                                <el-button type="text"><i class="el-icon-check"></i></el-button>
                            </template>
                        </el-table-column>
                      </el-table-column>
      <el-table-column label="二六">
          <el-table-column label="早" prop="zao" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="中" prop="zhong" width="40">
                <template slot-scope="scope" v-show="zhong">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
          </el-table-column>
          <el-table-column label="晚" prop="wan" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
          <el-table-column label="夜" prop="ye" width="40">
              <template slot-scope="scope">
                  <el-button type="text"><i class="el-icon-check"></i></el-button>
              </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="二七">
            <el-table-column label="早" prop="zao" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="中" prop="zhong" width="40">
                  <template slot-scope="scope" v-show="zhong">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
            </el-table-column>
            <el-table-column label="晚" prop="wan" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
            <el-table-column label="夜" prop="ye" width="40">
                <template slot-scope="scope">
                    <el-button type="text"><i class="el-icon-check"></i></el-button>
                </template>
            </el-table-column>
          </el-table-column>
          <el-table-column label="二八">
              <el-table-column label="早" prop="zao" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="中" prop="zhong" width="40">
                    <template slot-scope="scope" v-show="zhong">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
              </el-table-column>
              <el-table-column label="晚" prop="wan" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
              <el-table-column label="夜" prop="ye" width="40">
                  <template slot-scope="scope">
                      <el-button type="text"><i class="el-icon-check"></i></el-button>
                  </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="二九">
                <el-table-column label="早" prop="zao" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="中" prop="zhong" width="40">
                      <template slot-scope="scope" v-show="zhong">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="晚" prop="wan" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="夜" prop="ye" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
              </el-table-column>
             <el-table-column label="三十">
                <el-table-column label="早" prop="zao" width="40">
                      <template slot-scope="scope">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="中" prop="zhong" width="40">
                      <template slot-scope="scope" v-show="zhong">
                          <el-button type="text"><i class="el-icon-check"></i></el-button>
                      </template>
                </el-table-column>
                <el-table-column label="晚" prop="wan" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="夜" prop="ye" width="40">
                    <template slot-scope="scope">
                        <el-button type="text"><i class="el-icon-check"></i></el-button>
                    </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="三一">
                 <el-table-column label="早" prop="zao" width="40">
                       <template slot-scope="scope">
                           <el-button type="text"><i class="el-icon-check"></i></el-button>
                       </template>
                 </el-table-column>
                 <el-table-column label="中" prop="zhong" width="40">
                       <template slot-scope="scope" v-show="zhong">
                           <el-button type="text"><i class="el-icon-check"></i></el-button>
                       </template>
                 </el-table-column>
                 <el-table-column label="晚" prop="wan" width="40">
                     <template slot-scope="scope">
                         <el-button type="text"><i class="el-icon-check"></i></el-button>
                     </template>
                 </el-table-column>
                 <el-table-column label="夜" prop="ye" width="40">
                     <template slot-scope="scope">
                         <el-button type="text"><i class="el-icon-check"></i></el-button>
                     </template>
                 </el-table-column>
               </el-table-column>

      </el-table-column>
  </el-table>
  <el-pagination background layout="prev, pager, next"  :total="1000" style="float:right;"></el-pagination>
</div>
`;

var mobanTable = Vue.component('mobanTable',
  {
    name: 'mobanTable',
    template:template,
    data() {
      return {
        mobanTableDatas: [{
            name: '模板套餐',
            date: '2018.1.1',
            school: '北京理工大学',
            xiaoqu: '东校区',
            shitangname: '某某清真食堂',
            dangkou: 13,
            zao:'1',
            zhong:'1',
            wan:'0',
            ye:'0',
            seen:true
          }],
          mobanxiangqingModel:false
      }
    },
    methods: {
     deleteRow(index, rows) {
       rows.splice(index, 1);
     }
   }
  }
)
