// {{canteenList}}这个是放在div后面的第一个div

var template = `<div>
日期（月份）：
<el-date-picker
    v-model="value4"
    type="month"
    placeholder="选择月">
</el-date-picker>
<div style="float:right;">
  <el-button type="primary" icon="el-icon-edit" size="medium">已生成</el-button>
  <el-button type="primary" icon="el-icon-edit" size="medium">未生成</el-button>
  <router-link to="/createmenu"><el-button type="primary" icon="el-icon-document" size="medium">生成菜单</el-button></router-link>
  <el-button type="primary" icon="el-icon-view" size="medium">查看菜单</el-button>
</div>
<el-collapse v-model="activeNames" style="margin-top:10px;">
  <el-collapse-item v-for="(item,index) in canteenList" :key="item.id" :title="item.name" :name="item.id">
      <simpleCalander :month="value4">
         <template slot-scope="scope">
             <p>
                 <el-checkbox label="早" :checked="isChecked(scope.days,scope.date,'早',item,index)" @change="changeChecked(scope.date,'早',item.name,$event)"></el-checkbox>
                 <el-checkbox label="中" :checked="isChecked(scope.days,scope.date,'中',item,index)"></el-checkbox>
             </p>
             <p>
                 <el-checkbox label="晚"></el-checkbox>
                 <el-checkbox label="夜"></el-checkbox>
             </p>
         </template>
      </simpleCalander>
  </el-collapse-item>
</el-collapse>
</div>
`;
var menuManager = Vue.component('menuManager',
  {
    template:template,
    data() {
      return {
        activeNames: ['1'],
        value4: '2018-01',
        canteenList:[
          {
            id:"11",
            name:"第一食堂"
          },
          {
            id:"12",
            name:"第er食堂"
          },
          {
            id:"13",
            name:"第san食堂"
          }
        ],
        planList:[
          {
            id:"11",
            name:"第一食堂",
            date:"2017-12-01",
            time:"早",
            isEdit:true
          },
          {
            id:"14",
            name:"第一食堂",
            date:"2017-12-02",
            time:"早",
            isEdit:true
          },
          {
            id:"12",
            name:"第er食堂",
            date:"2017-12-01",
            time:"中",
            isEdit:true
          },
          {
            id:"13",
            name:"第san食堂",
            date:"2017-12-01",
            time:"早",
            isEdit:true
          }
        ]
      }
    },
    methods: {
        // initCheckList(date,time,name){
        //
        // },
        isChecked(days,date,time,item,index){
          // console.log(this.canteenList[index].days);
          //
          // Vue.set( this.canteenList[index], "days", days )
          for (var i in this.planList) {
            if(this.planList[i].name===item.name){
              if(this.planList[i].date===date){
                if(time===this.planList[i].time){
                  return true
                }
              }
            }
          }
        },
        changeChecked(date,time,name,e){
          console.log(e);
        }
    }
  }
)
