var template= `
<div>
  <div style="margin-bottom:16px;">
  <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/menu' }">菜单管理</el-breadcrumb-item>
    <el-breadcrumb-item>生成菜单</el-breadcrumb-item>
  </el-breadcrumb>
  </div>
    <el-form :inline="true" :model="formInline" label="right" :label-position="labelPosition" label-width="80px" class="demo-form-inline">
        <el-form-item label="选择日期:">
            <el-date-picker v-model="formInline.riqi"  type="daterange"  range-separator="至"  start-placeholder="开始日期"  end-placeholder="结束日期" format="yyyy - MM - dd"  value-format="yyyy-MM-dd">
            </el-date-picker>
        </el-form-item>
        <el-form-item label="周期:">
            <el-checkbox-group v-model="formInline.checkList">
                <el-checkbox label="周一">周一</el-checkbox>
                <el-checkbox label="周二">周二</el-checkbox>
                <el-checkbox label="周三">周三</el-checkbox>
                <el-checkbox label="周四">周四</el-checkbox>
                <el-checkbox label="周五">周五</el-checkbox>
                <el-checkbox label="周六">周六</el-checkbox>
                <el-checkbox label="周日">周日</el-checkbox>
            </el-checkbox-group>
        </el-form-item><br/>
        <el-form-item label="院校:">
            <el-select v-model="formInline.yuanxiao" placeholder="院校">
              <el-option label="北京交通大学" value="北京交通大学"></el-option>
              <el-option label="北京理工大学" value="北京理工大学"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="校区:">
            <el-select v-model="formInline.xiaoqu" placeholder="校区">
              <el-option label="东校区" value="东校区"></el-option>
              <el-option label="西校区" value="西校区"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="食堂:">
            <el-select v-model="formInline.shitang" placeholder="食堂">
              <el-option label="东食堂" value="东食堂"></el-option>
              <el-option label="西食堂" value="西食堂"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="档口:">
            <el-select v-model="formInline.dangkou" placeholder="档口">
              <el-option label="东档口" value="东档口"></el-option>
              <el-option label="西档口" value="西档口"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="medium" icon="el-icon-search"  @click="onSubmit">查询</el-button>
        </el-form-item>
    </el-form>
    <div style="float:right;">
      <el-button type="success" size="mini" icon="el-icon-plus" @click="chengbenjisuan = true">成本计算</el-button>
      <el-button type="success" size="mini" icon="el-icon-plus" @click="shengchengshicaibiao = true">生成食材表</el-button>
      <el-button type="success" size="mini" icon="el-icon-edit-outline">编辑</el-button>
      <el-button type="success" size="mini" icon="el-icon-plus">保存</el-button>
    </div>
    <el-table  :data="tableData5"  style="width: 100%">
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-button type="success" size="mini" icon="el-icon-plus">添加模板</el-button>
            <el-button type="success" size="mini" icon="el-icon-plus">添加菜品</el-button>
              <el-table ref="tableData"  :data="props.row.tableData" tooltip-effect="dark"  style="width: 100%" @selection-change="handleSelectionChange">
                <el-table-column  type="selection"  width="55"></el-table-column>
                <el-table-column  prop="img"  label="图片"></el-table-column>
                <el-table-column  prop="caiming"  label="菜名"></el-table-column>
                <el-table-column  prop="danjia"  label="单价"></el-table-column>
                <el-table-column  prop="yugufenshu"  label="预估份数"></el-table-column>
                <el-table-column  prop="yuguchengben"  label="预估成本"></el-table-column>
                <el-table-column  prop="shengchanfenshu"  label="生产份数"></el-table-column>
                <el-table-column  prop="shengchanchengben"  label="生产成本"></el-table-column>
                <el-table-column  prop="xiaoshoufenshu"  label="销售份数"></el-table-column>
                <el-table-column  prop="xiaoshouchengben"  label="销售成本"></el-table-column>
                <el-table-column  prop="xiaoshoue"  label="销售额"></el-table-column>
                <el-table-column  prop="shijishouyi"  label="实际收益"></el-table-column>
                <el-table-column  label="操作"  width="100">
                    <template slot-scope="scope">
                      <el-button type="text" size="small" @click='editShow(scope.row,scope.$index)'><i class="el-icon-edit"></i></el-button>
                      <el-button type="text" size="small"><i class="el-icon-sort"></i></el-button>
                      <el-button type="text" size="small"><i class="el-icon-delete"></i></el-button>
                    </template>
                </el-table-column>
              </el-table>
          </template>
        </el-table-column>
        <el-table-column  label="食堂"  prop="shitangtable"></el-table-column>
        <el-table-column  label="档口"  prop="dangkoutable"></el-table-column>
        <el-table-column  label="日期"  prop="riqitable"></el-table-column>
        <el-table-column  label="时间段"  prop="shijianduantable"></el-table-column>
  </el-table>

  <el-dialog  title="成本计算"  :visible.sync="chengbenjisuan"  width="30%"  :before-close="handleClose">
      <span>这是一段信息</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="chengbenjisuan = false">取 消</el-button>
        <el-button type="primary" @click="chengbenjisuan = false">确 定</el-button>
      </span>
  </el-dialog>

  <el-dialog  title="生成食材表"  :visible.sync="shengchengshicaibiao"  width="30%"  :before-close="handleClose">
      <span>这是一段信息</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="shengchengshicaibiao = false">取 消</el-button>
        <el-button type="primary" @click="shengchengshicaibiao = false">确 定</el-button>
      </span>
  </el-dialog>

  <el-dialog  title="菜品编辑"  :visible.sync="bianji"  width="30%"  :before-close="handleClose">
      <el-form :label-position="bianjiForm" label-width="80px" :model="bianjiForm" label="right">
          <el-form-item label="预估份数:">
              <el-input v-model="bianjiForm.yugufenshu"></el-input>
          </el-form-item>
          <el-form-item label="生产份数:">
              <el-input v-model="bianjiForm.shengchanfenshu"></el-input>
          </el-form-item>
          <el-form-item label="销售份数:">
              <el-input v-model="bianjiForm.xiaoshoufenshu"></el-input>
          </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="bianji = false">取 消</el-button>
        <el-button type="primary" @click="editDo">确 定</el-button>
      </span>
  </el-dialog>
</div>
`;
var createMenu = Vue.component('createMenu',
  {
    template:template,
    data() {
      return {
        formInline: {
          riqi: '',
          checkList:[],
          yuanxiao:'',
          xiaoqu:'',
          shitang:'',
          dangkou:'',
        },
        chengbenjisuan:false,
        shengchengshicaibiao:false,
        bianji:false,
        tableData5: [{
          shitangtable:'第一食堂',
          dangkoutable:'22档口',
          riqitable:'2015-1-1',
          shijianduantable:'早',
          tableData:[{
            id:'1',
            img:'1',
            caiming:'1',
            danjia:'1',
            yugufenshu:'2',
            yuguchengben:'1',
            shengchanfenshu:'1',
            shengchanchengben:'1',
            xiaoshoufenshu:'1',
            xiaoshouchengben:'1',
            xiaoshoue:'1',
            shijishouyi:'1'
          },{
            id:'1',
            img:'1',
            caiming:'1',
            danjia:'1',
            yugufenshu:'2',
            yuguchengben:'1',
            shengchanfenshu:'1',
            shengchanchengben:'1',
            xiaoshoufenshu:'1',
            xiaoshouchengben:'1',
            xiaoshoue:'1',
            shijishouyi:'1'
          }]
        }],
        bianjiForm:{
          yugufenshu:'',
          shengchanfenshu:'',
          xiaoshoufenshu:''
        },

      }
    },
    methods: {
      editShow(row,_index){
           //记录索引
           this.listIndex=_index;
           //记录数据
           this.bianjiForm=row;
           //显示弹窗
           this.bianji=true;
       },
       editDo(){
           let _index=this.listIndex
           //根据索引，赋值到list制定的数
           this.tableData5.tableData[_index]=bianjiForm;
           //关闭弹窗
           this.bianji=false;
       }
    }
  }
)
